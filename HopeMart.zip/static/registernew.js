window.addEventListener("load",addListener);


function CheckInfo()
{	
	document.getElementById("username").focus();
	var user = document.getElementById("username").value;
    var pass = document.getElementById("password").value;
	var repass = document.getElementById("repassword").value;

    if (user == "" || pass == "" || repass == "") 
	{
        alert("Please fill out both username and password.");
        return false;
    } 
	if (repass != pass)
	{
		alert("Passwords do not match. Please try again.");
		return false;
	else 
	{
		if (user == "admin" && pass == "adminpassword") 
		{
			alert("Admin account already exists. Use a different username or password.");
	        document.getElementById("username").value = ""
			document.getElementById("password").value = ""
			return false;
		} 
		return true;
	
	}
	
}
