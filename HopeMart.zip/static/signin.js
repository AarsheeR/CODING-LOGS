function CheckDirect()
{	
	document.getElementById("username").focus();
    var user = document.getElementById("username").value;
    var pass = document.getElementById("password").value;
    if (user == "" || pass == "") 
	{
        alert("Username and password cannot be empty.");
        return false;
    }
	return true;
}

