window.addEventListener("load",InitControls);
window.addEventListener("load",addListener);

function InitControls() {
    document.getElementById("txtproductname").value = "";
	productNameInput.readOnly = false;
    document.getElementById("txtproductprice").value = "";
    document.getElementById("txtproductname").focus();
}

function addListener() {
    document.getElementById("addProductBtn").addEventListener("click", handleProductSubmit);
}

function handleProductSubmit() {
	let name = document.getElementById("txtproductname").value;
    let price = document.getElementById("txtproductprice").value;
    let unit = document.getElementById("txtunit").value;
	
    if (unit == "" || price == "" || name == "")
	{
		if(unit == "")
		{
			alert("Please select a unit/size.")
			document.getElementById("txtunit").focus();
		}
		if(price == "")
		{
			alert("Please enter a price.")
			document.getElementById("txtproductprice").focus();
		}
		if(name == "")
		{
			alert("Please enter a product name.")
			document.getElementById("txtproductname").focus();
		}
	}
	if (!isValidPrice(price)) {
		alert("Price must be a number with at most one decimal point.");
		document.getElementById("txtproductprice").focus();
	}
	else
	{
		submitForm();
	}
}

function isValidPrice(price) {
	let dotCount = 0;

	for (let i = 0; i < price.length; i++) {
		let ch = price[i];
		if (ch == ".") {
			dotCount++;
			if (dotCount > 1) {
				return false;
			}
		} else if (ch < "0" || ch > "9") {
			return false;
		}
	}

	return true;
}

function submitForm() {
    const sectionName = document.getElementById("sectionTitle").textContent;

    switch (sectionName) 
	{
		
		case "Grocery":
			document.getElementById("GroceryForm").submit();
			break;
		case "Pre-made Meals":
			document.getElementById("PremadeForm").submit();
			break;
		case "Baked Goods":
			document.getElementById("BakeryForm").submit();
			break;
	    case "Womens":
			document.getElementById("WomensForm").submit();
			break;
		case "Mens":
			document.getElementById("MensForm").submit();
			break;
		case "Kids":
			document.getElementById("KidsForm").submit();
			break;
		case "Furniture":
			document.getElementById("FurnitureForm").submit();
			break;
		case "Electronics":
			document.getElementById("ElectronicsForm").submit();
			break;
		case "Household Needs":
			document.getElementById("HomeForm").submit();
			break;
		default:
			alert("System Error: Restart");
	}
}


function updateProductFromImage() { 
	let imageSelect = document.getElementById("Selectimg"); 
	let productNameInput = document.getElementById("txtproductname"); 
	let selectedOption = imageSelect.options[imageSelect.selectedIndex]; 
	let imgPreview = document.getElementById("imagePreview"); 
	imgPreview.src = "/static/" + selectedOption.value; 
	
	if (selectedOption.value === "none.png") 
	{ 
		productNameInput.value = ""; 
		productNameInput.readOnly = false; 
		productNameInput.disabled = false; 
		productNameInput.focus(); 
	} 
	else { 
		productNameInput.value = selectedOption.text; 
		productNameInput.readOnly = true; 
		productNameInput.disabled = false; 
	} 
}