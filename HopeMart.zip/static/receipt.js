function setDonation(amount, button) {
    document.getElementById("donationValue").value = amount;

    
    let subtotalText = document.getElementById("subtotal").innerText;
    let taxText = document.getElementById("tax").innerText;

    let subtotal = parseFloat(subtotalText.split("$")[1]) || 0;
    let tax = parseFloat(taxText.split("$")[1]) || 0;
    
    let newTotal = subtotal + tax + amount;

    document.getElementById("donation").innerText = "Donation: $" + amount.toFixed(2);
    document.getElementById("total").innerText = "Total: $" + newTotal.toFixed(2);

    if (amount > 0) {
        alert("Thank you for choosing to donate $" + amount.toFixed(2) + "!");
    } else {
        alert("Donation removed.");
    }
}

