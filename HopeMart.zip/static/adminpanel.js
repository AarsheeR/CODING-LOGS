function loggingout(){
		alert("You have been logged out.")
		window.location.href="/"
}
