window.addEventListener("load",addListener);

function addListener()
{
	document.getElementById("adminsignbtn").addEventListener("click",AdminDirect)
	document.getElementById("usersignbtn").addEventListener("click",UserDirect)
}

function AdminDirect()
{
	window.location.href = "/adminsignin";
	
}
function UserDirect()
{	
	window.location.href = "/usersignin";
	
}
