from flask import Flask,render_template,request
import sys
import os.path
from os import path

app = Flask(__name__)

#ADMIN USER NAME = admin; ADMIN PASSWORD = adminpassword
def check_user(nameuser,wordpass):
    filename = nameuser + wordpass + ".txt";
    fileexist = bool(path.exists(filename));
    if(fileexist == True):
        return "true";
    else:
        return "invalid"

def DoesExist(thefile):
    global Bool;
    fileexist = bool(path.exists(thefile));
    if(fileexist == False):
        Bool = "false";
    else:
        Bool = "true";

adminuser = "admin";
adminpass = "adminpassword";
usertype = "";
DEPARTMENTS = [
    "Food", "Clothing", "Furniture"
]
       
@app.route('/')
def main():
    global adminuser, adminpass
    return render_template('page0.html')

@app.route('/adminsignin')
def admin_signin():
    global usertype
    usertype = "Admin"
    return render_template("signin.html",usertype=usertype)

@app.route('/usersignin', methods=['GET','POST'])
def user_signin():
    global usertype
    usertype = "User"
    return render_template("signin.html",usertype=usertype)

@app.route('/getinfosignin', methods=['GET','POST'])
def getinfo_signin():
    fileDir = os.path.dirname(os.path.realpath("__file__"));
    global signinusername, signinpassword;
    signinusername = request.form.get("username") or ""
    signinpassword = request.form.get("password") or "" 
    accountexists = check_user(signinusername,signinpassword);
    if(usertype == "Admin"):
        if(signinusername == adminuser and signinpassword == adminpass):
           print("Welcome Admin!")
           SaveCurrentUser();
        else:
            if(signinusername == adminuser):
                message = "Admin password is incorrect. Please try again."
                return render_template("signin.html",usertype=usertype, message=message)
            else:
                message = "Incorrect credentials. Please try again."
                return render_template("signin.html",usertype=usertype, message=message)
    match usertype:
        case "Admin":
            return render_template("adminpanel.html",usertype=usertype, departments=DEPARTMENTS)
        case "User":
            global capusername
            capusername = signinusername.capitalize();
            if (accountexists == "invalid"):
                message = "Invalid username or password. Please try signing in again or create a new account!";
                return render_template("signin.html",usertype=usertype, message=message)
            else:
                print("Greetings " + capusername + ", you have successfully logged in!");
                SaveCurrentUser();
                fileexist = bool(path.exists("currentreceipt.txt"))
                if(fileexist == False):
                    adminfile = open("currentreceipt.txt","x");
                    adminfile.close();
                return render_template("customerpanel.html", capusername=capusername,usertype=usertype)
    
        case default:
            return render_template("signin.html", message="Invalid user type. Please restart.")

def SaveCurrentUser():
    filename = "currentuser.txt";
    fileexist = bool(path.exists(filename));
    if(fileexist == False):
        adminfile = open(filename,"x");
        adminfile.close();
    Overwrite(filename);
def Overwrite(file):
        adminfile = open(file,"w");
        adminfile.write(signinusername + signinpassword + ".txt");
        adminfile.close(); 
    
@app.route('/createnew', methods=['GET','POST'])
def create_new():
    return render_template("registernew.html")

@app.route('/getinfocreate', methods=['POST'])   
def getinfo_create():
    accountexists = "false";
    username = request.form.get("username")
    password = request.form.get("password")
    repassword = request.form.get("repassword")

    if (username == "" or password == "" or repassword == ""):
        error = "Invalid input. Username and password cannot be empty."
        return render_template("registernew.html",error=error)
    if (repassword != password):
        error = "Passwords do not match. Please try again"
        return render_template("registernew.html",error=error)
    if (username == adminuser and password == adminpass):
        error = "This account already exists as the Admin. Try a different username and password.";
        return render_template("registernew.html",error=error)
    if (username == adminuser or username == "Admin"):
        error = "To avoid confusion with Admin credentials please do not use Admin as a username!";
        return render_template("registernew.html",error=error)
            
    accountexists = check_user(username,password);
    if(accountexists == "true"):
        error = "An account with these credentials already exists! Try a different username."
        return render_template("registernew.html",error=error)
    else:
        adminfile = open(username + password + ".txt", "w")
        adminfile.write("")
        adminfile.close()
        message = "Account created. Please sign in again..."
        return render_template("signin.html",message=message)

@app.route('/usermenu', methods=['GET', 'POST'])
def user_panel():
    return render_template("customerpanel.html")

@app.route("/userpremade")
def upremade():
    message = ""
    return upremade_with_message(message)
    
def upremade_with_message(msg):
    global filename, HtmlName
    filename = "Premade.txt"
    HtmlName = "userpremade.html"
    Retrieve(filename)
    adminfile = open(filename,"r+")
    allInfo = adminfile.read();
    infolen = len(allInfo);
    if(infolen == 0):
        message = "No products available at the moment."
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName,headings=headings, message=message);
    else:
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName, headings=headings, data=data, message=msg)

@app.route("/addtocart", methods=["POST"])
def add_to_cart():
    image = request.form.get("productimage")
    name = request.form.get("productname")
    price = request.form.get("productprice")
    unit = request.form.get("productunit")
    quantity = request.form.get("productquantity")

    with open("currentuser.txt", "r") as f:
        current_user = f.read().strip()

    product_line = image + "," + name + "," + price + "," + unit + "," + quantity + "\n"

    with open(current_user, "a") as f:
        f.write(product_line)
        
    message = name.capitalize() + " added to cart!"
    match (HtmlName):
        case "userpremade.html":
            return upremade_with_message(message)
        case "userbakery.html":
            return ubakery_with_message(message)
        case "usergrocery.html":
            return ugrocery_with_message(message)
        case "usermens.html":
            return umens_with_message(message)
        case "userkids.html":
            return ukids_with_message(message)
        case "userwomen.html":
            return uwomen_with_message(message)
        case "userfurniture.html":
            return ufurniture_with_message(message)
        case "userelectronics.html":
            return uelectronics_with_message(message)
        case "userhome.html":
            return uhome_with_message(message)
    
@app.route("/checkout")
def checkout():
    global empty,total
    empty = "false";
    with open("currentuser.txt", "r") as file:
        current_user = file.read().strip()

    items = [];
    subtotal = 0.0;
    if os.path.exists(current_user):
        with open(current_user, "r") as userfile:
            lines = userfile.readlines()
            for line in lines:
                item = line.strip().split(",");
                items.append(item);

                price = float(item[2]);
                quantity = int(item[4]);
                subtotal += price * quantity;
                
    else:
        print("SYSTEM ERROR: Please restart!");

    shipping = 0.0;  
    tax_rate = 0.08; 
    tax = subtotal * tax_rate;
    total = subtotal + shipping + tax;
    if (total == 0.0):
        empty = "true";
        emptymsg = "Shopping cart is empty.";
        return render_template("receipt.html",
            emptymsg=emptymsg,
            subtotal="N/A",
            tax="N/A",
            shipping="Free!",
            total="N/A"
            )
    else:
        with open("currentreceipt.txt", "w") as f:
            f.write("Subtotal: $" + str(round(subtotal, 2)) + "\n")
            f.write("Shipping: Free! " + "\n")
            f.write("Tax: $" + str(round(tax, 2)) + "\n")

        return render_template("receipt.html",
            items=items,
            subtotal=round(subtotal, 2),
            tax=round(tax, 2),
            shipping="Free!",
            total=round(total, 2)
    )


@app.route("/payment")
def payment():
    if (empty == "true"):
        emptymsg = "Shopping cart is empty. Nothing to place order for!";
        return render_template("receipt.html",
            emptymsg=emptymsg,
            subtotal="0",
            tax="0",
            donation="0",
            shipping="Free!",
            total="0"
            )
    else:
        return render_template("payment.html") 

@app.route("/placeorder", methods=["POST"])
def place_order():
    donation = request.form.get("donation")
    creditcard = request.form.get("creditcard")
    year = request.form.get("year")
    cvv = request.form.get("cvv")
    zipcode = request.form.get("zipcode")
    
    if (not creditcard.isdigit()):
        errormsg = "Credit card must be numbers only."
        return render_template("payment.html",errormsg=errormsg)
    if (not year.isdigit() or len(year) != 4):
        errormsg = "Year must be 4 digits."
        return render_template("payment.html",errormsg=errormsg)
    if (not cvv.isdigit()):
        errormsg = "CVV must be numbers only."
        return render_template("payment.html",errormsg=errormsg)
    if (not zipcode.isdigit()):
        errormsg = "ZIP code must be numbers only."
        return render_template("payment.html",errormsg=errormsg)
    
        
    with open("currentuser.txt", "r") as f:
        current_user = f.read().strip()
    adminfile = open(current_user,"w");
    adminfile.write("");
    adminfile.close(); 

    final_total = total + float(donation)
    summary = []
    if os.path.exists("currentreceipt.txt"):
        with open("currentreceipt.txt", "r") as f:
            summary = f.readlines()

    summary.append("Donation: $" + str(round(float(donation), 2)) + "\n")
    summary.append("Final Total: $" + str(round(final_total, 2)) + "\n")
    
    return render_template("thankyou.html", summary=summary)

@app.route("/usergrocery")
def ugrocery():
    message = ""
    return ugrocery_with_message(message)

def ugrocery_with_message(msg):
    global filename, HtmlName
    filename = "Grocery.txt"
    HtmlName = "usergrocery.html"
    Retrieve(filename)
    adminfile = open(filename,"r+")
    allInfo = adminfile.read();
    infolen = len(allInfo);
    if(infolen == 0):
        message = "No products available at the moment."
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName,headings=headings, message=message);
    else:
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName, headings=headings, data=data, message=msg)

@app.route("/userbakery")
def ubakery():
    message = ""
    return ubakery_with_message(message)

def ubakery_with_message(msg):
    global filename, HtmlName
    filename = "Bakery.txt"
    HtmlName = "userbakery.html"
    Retrieve(filename)
    adminfile = open(filename,"r+")
    allInfo = adminfile.read();
    infolen = len(allInfo);
    if(infolen == 0):
        message = "No products available at the moment."
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName,headings=headings, message=message);
    else:
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName, headings=headings, data=data, message=msg)
@app.route("/usermens")
def umens():
    message = ""
    return umens_with_message(message)

def umens_with_message(msg):
    global filename, HtmlName
    filename = "Mens.txt"
    HtmlName = "usermens.html"
    Retrieve(filename)
    adminfile = open(filename,"r+")
    allInfo = adminfile.read();
    infolen = len(allInfo);
    if(infolen == 0):
        message = "No products available at the moment."
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName,headings=headings, message=message);
    else:
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName, headings=headings, data=data, message=msg)

@app.route("/userwomens")
def uwomens():
    message = ""
    return uwomen_with_message(message)

def uwomen_with_message(msg):
    global filename, HtmlName
    filename = "Womens.txt"
    HtmlName = "userwomen.html"
    Retrieve(filename)
    adminfile = open(filename,"r+")
    allInfo = adminfile.read();
    infolen = len(allInfo);
    if(infolen == 0):
        message = "No products available at the moment."
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName,headings=headings, message=message);
    else:
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName, headings=headings, data=data, message=msg)
    
@app.route("/userkids")
def ukids():
    message = ""
    return ukids_with_message(message)

def ukids_with_message(msg):
    global filename, HtmlName
    filename = "Kids.txt"
    HtmlName = "userkids.html"
    Retrieve(filename)
    adminfile = open(filename,"r+")
    allInfo = adminfile.read();
    infolen = len(allInfo);
    if(infolen == 0):
        message = "No products available at the moment."
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName,headings=headings, message=message);
    else:
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName, headings=headings, data=data, message=msg)

@app.route("/userhome")
def uhome():
    message = ""
    return uhome_with_message(message)

def uhome_with_message(msg):
    global filename, HtmlName
    filename = "Home.txt"
    HtmlName = "userhome.html"
    Retrieve(filename)
    adminfile = open(filename,"r+")
    allInfo = adminfile.read();
    infolen = len(allInfo);
    if(infolen == 0):
        message = "No products available at the moment."
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName,headings=headings, message=message);
    else:
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName, headings=headings, data=data, message=msg)

@app.route("/userfurniture")
def ufurniture():
    message = ""
    return ufurniture_with_message(message)

def ufurniture_with_message(msg):
    global filename, HtmlName
    filename = "Furniture.txt"
    HtmlName = "userfurniture.html"
    Retrieve(filename)
    adminfile = open(filename,"r+")
    allInfo = adminfile.read();
    infolen = len(allInfo);
    if(infolen == 0):
        message = "No products available at the moment."
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName,headings=headings, message=message);
    else:
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName, headings=headings, data=data, message=msg)

@app.route("/userelectronics")
def uelectronics():
    message = ""
    return uelectronics_with_message(message)

def uelectronics_with_message(msg):
    global filename, HtmlName
    filename = "Electronics.txt"
    HtmlName = "userelectronics.html"
    Retrieve(filename)
    adminfile = open(filename,"r+")
    allInfo = adminfile.read();
    infolen = len(allInfo);
    if(infolen == 0):
        message = "No products available at the moment."
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName,headings=headings, message=message);
    else:
        headings = ("Image", "Product", "Price", "Unit")
        return render_template(HtmlName, headings=headings, data=data, message=msg)

@app.route('/adminmenu', methods=['GET', 'POST'])
def admin_panel():
    return render_template("adminpanel.html")

@app.route("/grocery")
def grocery():
    global filename,HtmlName
    filename = "Grocery.txt"
    HtmlName = "grocery.html"
    return GeneralProcess(filename,HtmlName)

def GeneralProcess(dep_filename,dep_html):
    DoesExist(dep_filename);
    if(Bool == "false"):
        print("System Error: Systems missing. Creating new system...")
        adminfile = open(dep_filename,"x")
        adminfile.close()
        message = "No products available at the moment."
        return render_template(dep_html,message=message)
    else:
        adminfile = open(dep_filename,"r+")
        allInfo = adminfile.read();
        infolen = len(allInfo);
        if(infolen == 0):
            message = "No products available at the moment."
            return render_template(dep_html,message=message);
        else:
            Retrieve(dep_filename);
            headings = ("Image","Product","Price","Unit")
            return render_template(dep_html,headings = headings,data = data)

@app.route('/cleargrocery', methods=['POST'])
def cleargrocery():
    with open('grocery.txt', 'w') as f:
        f.write('')
    message = "No products available at the moment."
    return render_template("grocery.html",message=message);  

@app.route("/groceryinfo",methods=["POST"])
def GetgroceryInfo():
    return SecGeneralProcess(filename,HtmlName)
    
def SecGeneralProcess(dep_filename,dep_html):
    GetProductInfo();
    AddProductInfo(dep_filename);
    Retrieve(dep_filename);
    headings = ("Image","Product","Price","Unit")
    return render_template(dep_html,headings = headings,data = data)

def GetProductInfo():
    global pimage,pname,pprice,punit;
    pimage = request.form.get('Selectimg');
    pname = request.form.get('txtproductname');
    pprice = request.form.get('txtproductprice');
    punit = request.form.get('txtunit');

def AddProductInfo(thefile):
    DoesExist(thefile);
    if(Bool == "false"):
        adminfile = open(thefile,"x");
        adminfile.close();
    WriteInfo(thefile);

def WriteInfo(file):
    adminfile = open(file,"r+")
    allInfo = adminfile.read();
    infolength = len(allInfo);
    if(infolength == 0):
        adminfile = open(file,"w")
        adminfile.write(str(pimage) + ";" + str(pname) + ";" + str(pprice) + ";" + str(punit));
    else:
        adminfile = open(file,"a")
        adminfile.write(";" + str(pimage) + ";" + str(pname) + ";" + str(pprice) + ";" + str(punit));
    adminfile.close()


def Retrieve(theFile):
    global data,product,price,image,unit
    data = [];
    product = [];
    price = [];
    image = [];
    unit = [];
    adminfile = open(theFile,"r+")
    allInfo = adminfile.read().split(";");
    length = (len(allInfo)/4);
    num = 0
    
    for i in range(int(length)):
        currentimage = allInfo[num];
        currentname = allInfo[num+1];
        currentprice = allInfo[num+2];
        currentunit = allInfo[num+3];

        subdata = [];

        subdata.append(currentimage);
        subdata.append(currentname);
        subdata.append(currentprice);
        subdata.append(currentunit);

        image.append(currentimage);
        product.append(currentname);
        price.append(currentprice);
        unit.append(currentunit);

        num = num+4;
        data.append(subdata);

@app.route("/kids")
def kids():
    global filename,HtmlName,infolen
    filename = "Kids.txt"
    HtmlName = "kids.html"
    return GeneralProcess(filename,HtmlName)

@app.route('/clearkids', methods=['POST'])
def clearkidsfood():
    with open('Kids.txt', 'w') as f:
        f.write('')
    message = "No products available at the moment."
    return render_template("kids.html",message=message);  

@app.route("/kidsinfo",methods=["POST"])
def GetaccessoriesInfo():
    return SecGeneralProcess(filename,HtmlName)

@app.route("/mens")
def mens():
    global filename,HtmlName,infolen
    filename = "Mens.txt"
    HtmlName = "mens.html"
    return GeneralProcess(filename,HtmlName)

@app.route('/clearmens', methods=['POST'])
def clearmens():
    with open('Mens.txt', 'w') as f:
        f.write('')
    message = "No products available at the moment."
    return render_template("mens.html",message=message);  

@app.route("/mensinfo",methods=["POST"])
def GetmensInfo():
    return SecGeneralProcess(filename,HtmlName)

@app.route("/womens")
def womens():
    global filename,HtmlName,infolen
    filename = "Womens.txt";
    HtmlName = "womens.html"
    return GeneralProcess(filename,HtmlName)

@app.route('/clearwomens', methods=['POST'])
def clearwomens():
    with open('Womens.txt', 'w') as f:
        f.write('')
    message = "No products available at the moment."
    return render_template("womens.html",message=message);  

@app.route("/womensinfo",methods=["POST"])
def GetwomensInfo():
    return SecGeneralProcess(filename,HtmlName)

@app.route("/bakery")
def bakery():
    global filename,HtmlName,infolen
    filename = "Bakery.txt"
    HtmlName = "bakery.html"
    return GeneralProcess(filename,HtmlName)

@app.route('/clearbakery', methods=['POST'])
def clearbakery():
    with open('Bakery.txt', 'w') as f:
        f.write('')
    message = "No products available at the moment."
    return render_template("bakery.html",message=message);  

@app.route("/bakeryinfo",methods=["POST"])
def GetbakeryInfo():
    return SecGeneralProcess(filename,HtmlName)

@app.route("/furniture")
def furniture():
    global filename,HtmlName,infolen
    filename = "Furniture.txt"
    HtmlName = "furniture.html"
    return GeneralProcess(filename,HtmlName)

@app.route('/clearfurniture', methods=['POST'])
def clearfurniture():
    with open('Furniture.txt', 'w') as f:
        f.write('')
    message = "No products available at the moment."
    return render_template("furniture.html",message=message);  

@app.route("/furnitureinfo",methods=["POST"])
def GetfurnitureInfo():
    return SecGeneralProcess(filename,HtmlName)

@app.route("/electronics")
def electronics():
    global filename,HtmlName,infolen
    filename = "Electronics.txt"
    HtmlName = "electronics.html"
    return GeneralProcess(filename,HtmlName)

@app.route('/clearelectronics', methods=['POST'])
def clearelectronics():
    with open('Electronics.txt', 'w') as f:
        f.write('')
    message = "No products available at the moment."
    return render_template("electronics.html",message=message);  

@app.route("/electronicsinfo",methods=["POST"])
def GetelectronicsInfo():
    return SecGeneralProcess(filename,HtmlName)

@app.route("/home")
def home():
    global filename,HtmlName,infolen
    filename = "Home.txt"
    HtmlName = "home.html"
    return GeneralProcess(filename,HtmlName)

@app.route('/clearhome', methods=['POST'])
def clearhome():
    with open('Home.txt', 'w') as f:
        f.write('')
    message = "No products available at the moment."
    return render_template("home.html",message=message);  

@app.route("/homeinfo",methods=["POST"])
def GethomeInfo():
    return SecGeneralProcess(filename,HtmlName)

@app.route("/premade")
def premade():
    global filename,HtmlName,infolen
    filename = "Premade.txt"
    HtmlName = "premade.html"
    return GeneralProcess(filename,HtmlName)

@app.route('/clearpremade', methods=['POST'])
def clearpremade():
    with open('Premade.txt', 'w') as f:
        f.write('')
    message = "No products available at the moment."
    return render_template("premade.html",message=message);  

@app.route("/premadeinfo",methods=["POST"])
def GetpremadeInfo():
    return SecGeneralProcess(filename,HtmlName)

@app.route("/homeless", methods=["GET", "POST"])
def Homeless():
    return render_template("Homeless.html");

if __name__ == "__main__":
    app.run()
