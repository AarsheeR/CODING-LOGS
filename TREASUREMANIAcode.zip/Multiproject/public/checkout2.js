document.getElementById("btnsave").onclick = function() {
    // Check if each input field is filled
    if (document.getElementById("firstname").value == "") {
        alert("Please enter your first name.");
        return;
    }
    if (document.getElementById("secondname").value == "") {
        alert("Please enter your second name.");
        return;
    }
    if (document.getElementById("address1").value == "") {
        alert("Please enter your address line 1.");
        return;
    }
    if (document.getElementById("address2").value == "") {
        alert("Please enter your address line 2.");
        return;
    }
    if (document.getElementById("zipcode").value == "") {
        alert("Please enter your ZIP code.");
        return;
    }
    if (document.getElementById("state").value == "") {
        alert("Please enter your state.");
        return;
    }
    if (document.getElementById("city").value == "") {
        alert("Please enter your city.");
        return;
    }
    if (document.getElementById("phonenum").value == "") {
        alert("Please enter your phone number.");
        return;
    }

    // If all fields are filled, you can proceed
    alert("All fields are filled! Proceeding...");
};
